Place this file in C:\Users\YourName\BattleScribe\data\Warhammer 40,000 9th Edition. Listed as "Death Korps of Krieg (HB)" in BattleScribe.
Contains a mini-codex for Death Korps of Krieg and updates for many Forge World units, too many to list down but it's nearly everything sans flyers.

If you discover a bug, inconsistency or etc., click on the Issues tab, then New Issue. Describe your problem clearly and concisely and I'll fix it as soon as. You could also give me some criticism or give any ideas for this stuff.
You could also send me an email to an account I made at mong94bdc@hotmail.com.
Or you can send me a message to a discord account I also made at mong#2655. Just make sure you aren't a creep.

Check out my other homebrew catalogues:
https://github.com/mong01/Adeptus-Mechanicus-FW-Battlescribe
https://github.com/mong01/Daemons-FW-Update